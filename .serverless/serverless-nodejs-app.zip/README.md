# Deployment Information

To deploy, run `serverless deploy`

To undeploy, run `serverless remove`
